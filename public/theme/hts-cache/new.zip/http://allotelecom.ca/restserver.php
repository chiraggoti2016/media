

<!DOCTYPE html>
<html lang="fr-FR">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
              <meta name="theme-color" content="#be2323" />
            <link rel="profile" href="http://gmpg.org/xfn/11">
              <link href="http://allotelecom.ca/wp-content/uploads/2019/03/cropped-Allo-Tellecom-8-1.png" rel="icon">
            <link rel="pingback" href="http://allotelecom.ca/xmlrpc.php" />	  
      <title>Page non trouvée &#8211; Allo Telecom</title>
        <!-- Add Messenger - wp-chatbot - HoliThemes - https://www.holithemes.com/wp-chatbot -->
        <script>
            window.fbAsyncInit = function() {
            FB.init({
                appId            : '2015199145383303',
                autoLogAppEvents : false,
                xfbml            : true,
                version          : 'v3.2'
            });
            };

            (function(d, s, id){
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) {return;}
                js = d.createElement(s); js.id = id;
                js.src = '//connect.facebook.net/French (Canada)/sdk/xfbml.customerchat.js';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    <!-- / Add Messenger - wp-chatbot - HoliThemes -->
    <script type='text/javascript'>console.log('PixelYourSite Free version 7.0.5');</script>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Allo Telecom &raquo; Flux" href="http://allotelecom.ca/feed/" />
<link rel="alternate" type="application/rss+xml" title="Allo Telecom &raquo; Flux des commentaires" href="http://allotelecom.ca/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/allotelecom.ca\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.0.3"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='bootstrap-css'  href='http://allotelecom.ca/wp-content/themes/incubator/core/assets/css/bootstrap.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='parent-style-css'  href='http://allotelecom.ca/wp-content/themes/incubator/style.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css'  href='http://allotelecom.ca/wp-content/themes/incubator-child/style.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='http://allotelecom.ca/wp-includes/css/dist/block-library/style.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://allotelecom.ca/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://allotelecom.ca/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='http://allotelecom.ca/wp-content/plugins/contact-information-widget//style.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='kd_addon_style-css'  href='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/css/kd_vc_front.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://allotelecom.ca/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.8' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='wpml-legacy-horizontal-list-0-css'  href='//allotelecom.ca/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-list-horizontal/style.css?ver=1' type='text/css' media='all' />
<link rel='stylesheet' id='keydesign-style-css'  href='http://allotelecom.ca/wp-content/themes/incubator-child/style.css?ver=5.0.3' type='text/css' media='all' />
<style id='keydesign-style-inline-css' type='text/css'>
                        .expertisesec h4{ font-size: 50px !important; }
#expertisesection .vc_column-inner:hover{ background-color: #dd3333 !important;}
#expertisesection .vc_column-inner:hover h4 { color: #fff !important ; }
#expertisesection .vc_column-inner:hover p {  color: #fff !important ; }
#expertisesection .vc_column-inner:hover a.tt_button { background-color: #fff !important; color: #000 !important; }
#expertisesection .vc_column-inner:hover i.fa {
    color: #fff !important;
}
.fa-laptop:before, .fa-television:before, .fa-mobile:before { font-size: 70px; }
#expertisesection .vc_column-inner {
-webkit-box-shadow: 0 2px 4px 0 rgba(0,0,0,.5);
    box-shadow: 0 2px 4px 0 rgba(0,0,0,.5);
}

@media (max-width:680px){
    .expertisesec h4{ font-size: 30px !important;}
} 
section#contact-map { padding: 0px !important; }
@media (min-width: 960px){
.navbar.navbar-default {
    padding: 0px 0px !important
}
}

#charts .chart_heading{ font-size: 40px; line-height: 50px; margin-bottom: 0px; margin-top: 0px; }
.navbar.navbar-default.fullwidth { padding: 0 0 30px; } 
.top-bar { background: #000000; } 
.top-bar .container { display: flex; flex-wrap: wrap; align-items: center; } 
.type-list ul { display: flex; flex-wrap: wrap; align-items: center; list-style-type: none; margin: 0; padding: 0; } 
.type-list.right ul { justify-content: flex-end; } 
.type-list li a { font-size: 12px; text-decoretion: none; padding: 9px 20px; text-transform: capitalize; color: #fff; display: inline-block; 
line-height: 1.3; } 
.type-list li a:hover { background: rgb(221, 51, 51); color: #fff; } 
.wpml-ls-statics-footer a { color: #444444; background-color: none!important; padding: 0px!important;position: relative; top: 11px;}
@media (max-width: 680px){ 
	.navbar-fixed-top { padding: 0; min-height: 65px; position: relative !important; margin: 0px; } 
	.type-list { width: auto; } 
	.type-list li a { padding: 5px; } 
	.top-bar .container { padding: 5px 7px; } 
	#wrapper { padding-top: 0px !important; } 
	.wpml-ls-statics-footer a {position: relative; top: -11px; }
}                    
</style>
<link rel='stylesheet' id='js_composer_front-css'  href='http://allotelecom.ca/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-css'  href='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/css/photoswipe.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-skin-css'  href='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/css/photoswipe-default-skin.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='redux-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Lato%3A100%2C300%2C400%2C700%2C900%2C100italic%2C300italic%2C400italic%2C700italic%2C900italic%7CWork+Sans%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900&#038;ver=1559053916' type='text/css' media='all' />
<script type='text/javascript' src='http://allotelecom.ca/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/jquery.easing.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/owl.carousel.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/jquery.easytabs.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/jquery.appear.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/kd_addon_script.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/photoswipe.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/keydesign-addon/assets/js/photoswipe-ui-default.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/pixelyoursite/dist/scripts/jquery.bind-first-0.2.3.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/pixelyoursite/dist/scripts/js.cookie-2.1.3.min.js?ver=2.1.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pysOptions = {"staticEvents":{"facebook":{"PageView":[{"params":[],"delay":0,"ids":[]}],"GeneralEvent":[{"params":[],"delay":0,"ids":[]}]}},"facebook":{"pixelIds":["1741670889437646"],"advancedMatching":[],"removeMetadata":false,"contentParams":[],"commentEventEnabled":true,"wooVariableAsSimple":false,"downloadEnabled":true,"formEventEnabled":true},"ga":{"trackingIds":["UA-69395029-1"],"enhanceLinkAttr":false,"anonimizeIP":false,"commentEventEnabled":true,"commentEventNonInteractive":false,"downloadEnabled":true,"downloadEventNonInteractive":false,"formEventEnabled":true,"crossDomainEnabled":false,"crossDomainAcceptIncoming":false,"crossDomainDomains":[]},"debug":"","siteUrl":"http:\/\/allotelecom.ca","ajaxUrl":"http:\/\/allotelecom.ca\/wp-admin\/admin-ajax.php","commonEventParams":{"domain":"allotelecom.ca","user_roles":"guest","plugin":"PixelYourSite"},"commentEventEnabled":"1","downloadEventEnabled":"1","downloadExtensions":["","doc","exe","js","pdf","ppt","tgz","zip","xls"],"formEventEnabled":"1","gdpr":{"ajax_enabled":false,"all_disabled_by_api":false,"facebook_disabled_by_api":false,"analytics_disabled_by_api":false,"google_ads_disabled_by_api":false,"pinterest_disabled_by_api":false,"facebook_prior_consent_enabled":true,"analytics_prior_consent_enabled":true,"google_ads_prior_consent_enabled":null,"pinterest_prior_consent_enabled":true,"cookiebot_integration_enabled":false,"cookiebot_facebook_consent_category":"marketing","cookiebot_analytics_consent_category":"statistics","cookiebot_google_ads_consent_category":null,"cookiebot_pinterest_consent_category":"marketing","ginger_integration_enabled":false,"cookie_notice_integration_enabled":false,"cookie_law_info_integration_enabled":false},"woo":{"enabled":false,"addToCartOnButtonEnabled":true,"addToCartOnButtonValueEnabled":true,"addToCartOnButtonValueOption":"price","removeFromCartEnabled":true,"removeFromCartSelector":".cart .product-remove .remove"},"edd":{"enabled":false,"addToCartOnButtonEnabled":true,"addToCartOnButtonValueEnabled":true,"addToCartOnButtonValueOption":"price","removeFromCartEnabled":true}};
/* ]]> */
</script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/pixelyoursite/dist/scripts/public.js?ver=7.0.5'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://allotelecom.ca/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://allotelecom.ca/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.3" />
<meta name="generator" content="WPML ver:4.2.6 stt:1,4;" />
<script type="text/javascript">var ajaxurl = "http://allotelecom.ca/wp-admin/admin-ajax.php";</script><script type="text/javascript">
    var districtmPixel = {};
    districtmPixel.revenueValue = '0.00';
    (function(){
    var dm = document.createElement('script');
    dm.async = true;
    dm.src = '//cdn.pixlads.com/agencies/1/advertisers/621/audience.js';
    var ref = document.getElementsByTagName('script')[0];
    ref.parentNode.insertBefore(dm, ref);
})();
</script>
<style type="text/css" data-type="vc_shortcodes-custom-css-2484">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2488">.vc_custom_1548355828634{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1550156885214{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #353637 !important;}.vc_custom_1549372711816{background-color: #ffffff !important;}.vc_custom_1552513956164{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #be2323 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1544131862840{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}.vc_custom_1544131467824{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1475853293310{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #e9e9e9 !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548862130790{margin-top: -35px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-456">.vc_custom_1548355828634{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1550879742197{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #353637 !important;}.vc_custom_1549372711816{background-color: #ffffff !important;}.vc_custom_1552513929476{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #be2323 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1544131862840{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}.vc_custom_1544131467824{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1475853293310{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #e9e9e9 !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548862130790{margin-top: -35px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2493">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2533">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2562">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2601">.vc_custom_1551745352255{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}.vc_custom_1548874500563{padding-top: 50px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1551745218616{padding-top: 120px !important;padding-bottom: 100px !important;}.vc_custom_1550243543520{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1551745231961{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2667">.vc_custom_1549039687544{padding-top: 50px !important;padding-bottom: 30px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2695">.vc_custom_1549039481976{padding-top: 50px !important;padding-bottom: 10px !important;}.vc_custom_1549039490393{padding-top: 10px !important;padding-bottom: 10px !important;}.vc_custom_1549039503150{padding-top: 10px !important;padding-bottom: 10px !important;}.vc_custom_1549039510318{padding-top: 10px !important;padding-bottom: 10px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2741">.vc_custom_1549190064198{padding-top: 50px !important;padding-bottom: 7px !important;}.vc_custom_1549190072348{padding-top: 7px !important;padding-bottom: 7px !important;}.vc_custom_1549039503150{padding-top: 10px !important;padding-bottom: 10px !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2749">.vc_custom_1549190064198{padding-top: 50px !important;padding-bottom: 7px !important;}.vc_custom_1549190072348{padding-top: 7px !important;padding-bottom: 7px !important;}.vc_custom_1549039503150{padding-top: 10px !important;padding-bottom: 10px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2751">.vc_custom_1549039687544{padding-top: 50px !important;padding-bottom: 30px !important;}.vc_custom_1549039687544{padding-top: 50px !important;padding-bottom: 30px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2769">.vc_custom_1549193529159{padding-top: 30px !important;padding-bottom: 50px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1549193861008{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}.vc_custom_1549193867399{padding-top: 80px !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2786">.vc_custom_1549183015753{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #dd3333 !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1549196867696{padding-top: 30px !important;padding-bottom: 30px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1549183318467{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #dd3333 !important;}.vc_custom_1549183406260{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #0130b8 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}.vc_custom_1549196353140{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #0130b8 !important;}.vc_custom_1549196365388{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #dd3333 !important;}.vc_custom_1549196371722{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #0130b8 !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2801">.vc_custom_1549297660169{padding-top: 80px !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2918">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3104">.vc_custom_1548355828634{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1550879742197{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #353637 !important;}.vc_custom_1549372711816{background-color: #ffffff !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1544131862840{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;}.vc_custom_1544131467824{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1475853293310{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #e9e9e9 !important;}.vc_custom_1551292325961{padding-top: 120px !important;padding-bottom: 100px !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1548862130790{margin-top: -35px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-2989">.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3116">.vc_custom_1551292948603{padding-top: 50px !important;padding-bottom: 30px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3124">.vc_custom_1551294777093{padding-top: 60px !important;padding-bottom: 20px !important;}.vc_custom_1551295264038{padding-top: 40px !important;background-color: #f4f4f4 !important;}.vc_custom_1551295245258{padding-top: 0px !important;padding-bottom: 20px !important;background-color: #f4f4f4 !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3154">.vc_custom_1551294777093{padding-top: 60px !important;padding-bottom: 20px !important;}.vc_custom_1551295264038{padding-top: 40px !important;background-color: #f4f4f4 !important;}.vc_custom_1551295245258{padding-top: 0px !important;padding-bottom: 20px !important;background-color: #f4f4f4 !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3152">.vc_custom_1551294777093{padding-top: 60px !important;padding-bottom: 20px !important;}.vc_custom_1551295264038{padding-top: 40px !important;background-color: #f4f4f4 !important;}.vc_custom_1551295245258{padding-top: 0px !important;padding-bottom: 20px !important;background-color: #f4f4f4 !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css" data-type="vc_shortcodes-custom-css-3153">.vc_custom_1551294777093{padding-top: 60px !important;padding-bottom: 20px !important;}.vc_custom_1551295264038{padding-top: 40px !important;background-color: #f4f4f4 !important;}.vc_custom_1551295245258{padding-top: 0px !important;padding-bottom: 20px !important;background-color: #f4f4f4 !important;}.vc_custom_1552157094863{padding-top: 30px !important;padding-bottom: 70px !important;background-color: #dd3333 !important;}.vc_custom_1549783141325{padding-top: 40px !important;padding-bottom: 110px !important;background-color: #f8f8f8 !important;}.vc_custom_1548357049229{padding-top: 0px !important;padding-right: 0px !important;padding-bottom: 0px !important;padding-left: 0px !important;background-color: #ffffff !important;}.vc_custom_1548860449373{padding-bottom: 20px !important;}.vc_custom_1475853057895{padding: 0px !important;}.vc_custom_1475852312576{padding: 0px !important;}.vc_custom_1475853091335{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #ffffff !important;}.vc_custom_1475853286062{padding-top: 120px !important;padding-bottom: 100px !important;background-color: #f3f3f3 !important;}.vc_custom_1544530708106{padding-top: 120px !important;padding-bottom: 100px !important;}</style><style type="text/css">.tt_button:hover .iconita,
.tt_button.second-style .iconita,
#single-page #comments input[type="submit"]:hover,
.cb-heading,
.tt_button.tt_secondary_button,
.tt_button.tt_secondary_button .iconita,
.es-accordion .es-time,
.lower-footer .pull-left a:hover,
.vc_tta-container .vc_tta-color-white.vc_tta-style-modern .vc_tta-tab.vc_active>a,
.CountdownContent,
.wpcf7-select,
.woocommerce .star-rating span,
.navbar-default.navbar-shrink .nav li.active a,
#customizer .options a:hover i,
.woocommerce .price_slider_wrapper .price_slider_amount .button,
#customizer .options a:hover,
#single-page input[type="submit"]:hover,
#posts-content .post input[type="submit"]:hover,
.active .pricing-option .fa,
.modal-content-inner .wpcf7-not-valid-tip,
#posts-content #comments input[type="submit"]:hover,
.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,
#comments .reply a:hover,
.single-post .navigation.pagination .next:hover,
.single-post .navigation.pagination .prev:hover,
.meta-content .tags a:hover,
.navigation.pagination .next,
.navigation.pagination .prev,
#posts-content .entry-meta a:hover,
#posts-content .post .blog-single-title:hover,
.woocommerce span.onsale,
.product_meta a:hover,
.tags a:hover, .tagcloud a:hover,
.port-prev.tt_button,
.port-next.tt_button,
.footer_widget ul a:hover,
.tt_button.second-style,
.large-counter .kd_counter_units,
.lower-footer .pull-right a:hover,
.app-gallery .ag-section-desc h4,
.active .pricing .pricing-time,
.key-reviews:hover .rw-author-details h4,
.woocommerce-review-link:hover,
.rw_rating .rw-title,
.socials-widget a:hover .fa,
.section .wpcf7-mail-sent-ok,
.footer_widget .menu li a:hover,
.upper-footer .modal-menu-item,
.video-socials a:hover .fa,
.kd_pie_chart .pc-link a:hover,
.navbar-default.navbar-shrink .modal-menu-item:hover,
.navbar-default.navbar-shrink .nav li a:hover,
.navbar-default.navbar-shrink .nav li a:focus,
.vc_grid-item-mini .vc_gitem_row .vc_gitem-col h4:hover,
.navbar-default.navbar-shrink .nav li a:hover,
.navbar-default.navbar-shrink .nav li a:focus,
.fa,
.wpcf7 .wpcf7-submit:hover,
.contact .wpcf7-response-output,
.video-bg .secondary-button:hover,
#headerbg li a.active,
#headerbg li a.active:hover,
.footer-nav a:hover ,
.wpb_wrapper .menu a:hover ,
.text-danger,
.navigation.pagination .next:hover,
.navigation.pagination .prev:hover,
.blog_widget ul li a:before,
.active .pricing .fa,
.searchform #searchsubmit:hover,
code,
.video-container:hover .play-video .fa-play,
#single-page .single-page-content ul li:before,
.blog_widget ul li a:hover,
.subscribe-form header .wpcf7-submit,
#posts-content .page-content ul li:before,
.active .pricing .col-lg-3,
.chart-content .nc-icon-outline,
.chart,
.section .wpcf7-not-valid-tip,
.features-tabs .tab a.active,
.secondary-button-inverse,
.primary-button.button-inverse:hover,
.primary-button,
a,
.pss-link a:hover,
.woocommerce-cart #single-page .cart_totals table td,
.kd_number_string,
.featured_content_parent .active-elem h4,
.contact-map-container .toggle-map:hover .fa,
.contact-map-container .toggle-map:hover,
.tt_button:hover,
.nc-icon-outline,
.woocommerce ul.products li.product h3:hover,
.wpb_text_column ol>li:before,
.wpb_text_column ul>li:before,
.key-icon-box .ib-link a:hover,
.rw_message .rw-link a:hover,
.kd-photobox .phb-btncontainer a:hover {
			color: #be2323;
	}

.parallax.with-overlay:after,
.tt_button.tt_secondary_button:hover,
.vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li.vc_active a,
.vc_tta-container .vc_tta-color-white.vc_tta-style-modern.vc_tta-tabs .vc_tta-panels,
.wpb-js-composer .vc_tta-container .vc_tta-tabs .vc_tta-panels,
.wpb-js-composer .vc_tta-container .vc_tta-tabs.vc_tta-color-white.vc_tta-style-modern.vc_tta-tabs .vc_tta-panels,
#popup-modal .modal-content h2,
.tt_button.second-style:hover,
.pricing-table.active .tt_button,
.page-404,
.woocommerce ul.products li.product .added_to_cart,
.woocommerce #respond input#submit,
.woocommerce a.button,
.woocommerce button.button,
.woocommerce input.button,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.upper-footer .modal-menu-item:hover,
.contact-map-container .toggle-map,
.portfolio-item .portfolio-content,
.keydesign-cart .badge,
.wpcf7 .wpcf7-submit,
.tt_button,
.owl-controls .owl-page span,
#commentform #submit,
.woocommerce a.remove:hover,
.contact .wpcf7-submit,
.team-content-hover,
.pricing .secondary-button.secondary-button-inverse:hover,
#preloader,
.with-overlay .parallax-overlay,
.secondary-button.secondary-button-inverse:hover,
.secondary-button,
.primary-button.button-inverse,
#posts-content .post input[type="submit"],
.btn-xl,
.with-overlay,
.features-tabs .tab.active,
.woocommerce .price_slider_wrapper .ui-slider-horizontal .ui-slider-range,
.play-video,
.video-container:hover .play-video:hover,
.pricing-table.active .pricing-title,
.separator,
.woocommerce ul.products li.product .button:hover,
.kd-photobox:hover .phb-content,
#header,
.post-password-form input[type="submit"] {
			background-color: #be2323;
	}

.page404-overlay,
.navbar-shrink .modal-menu-item:hover,
.slider-scroll-down a {
			background-color: #be2323;
	}

::selection {
			background-color: #be2323;
	}

::-moz-selection {
			background-color: #be2323;
	}

#single-page #comments input[type="submit"]:hover,
#posts-content #comments input[type="submit"]:hover,
.navigation.pagination .next,
.navigation.pagination .prev,
.port-prev.tt_button,
.port-next.tt_button,
.upper-footer .modal-menu-item,
.navbar-default.navbar-shrink .modal-menu-item:hover,
.wpcf7 .wpcf7-submit:hover,
.tt_button:hover,
.woocommerce ul.products li.product .button:hover,
.woocommerce .price_slider_wrapper .ui-slider .ui-slider-handle,
.video-container:hover .play-video,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.pricing.active,
.primary-button.button-inverse:hover,
.primary-button.button-inverse,
.owl-controls .owl-page.active span,
.owl-controls .owl-page:hover span {
			border: 2px solid #be2323;
	}

.features-tabs .tab a.active .triangle  {
		  border-right: 10px solid #be2323;
	}

.tabs-image-right.features-tabs .tab a.active .triangle  {
		  border-left: 10px solid #be2323;
	}


.blockquote-reverse,
blockquote,
.tags a:hover, .tagcloud a:hover,
.contact-map-container .toggle-map:hover,
.navigation.pagination .next:hover, .navigation.pagination .prev:hover,
.contact .wpcf7-response-output,
.video-bg .secondary-button,
.image-bg .secondary-button,
.contact .wpcf7-form-control-wrap textarea.wpcf7-form-control:focus,
.contact .wpcf7-form-control-wrap input.wpcf7-form-control:focus,
.team-member-down:hover .triangle,
.team-member:hover .triangle,
.secondary-button-inverse  {
		  border-color: #be2323;
	}

.wpb-js-composer .vc_tta-container .vc_tta-tabs.vc_tta-color-white.vc_tta-style-modern.vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab:before,
.vc_tta-container  .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab:before {
		  border-right: 9px solid #be2323;
	}

.vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li:before {
		  border-top: 9px solid #be2323;
	}


.kd-calltoaction .tt_button.tt_secondary_button,
.kd_progress_bar .kd_progb_head .kd-progb-title h4,
.kd-photobox .phb-btncontainer a,
.key-icon-box .ib-link a,
.rw_message .rw-link a,
.vc_tta-container .vc_tta.vc_tta-style-classic .vc_tta-tabs-container .vc_tta-tabs-list li a,
 .es-accordion .es-heading h4 a,
.vc_tta-color-white.vc_tta-style-modern .vc_tta-tab>a:hover,
.pricing-option .fa,
#comments .reply a,
#comments .fn,
#comments .fn a,
.single-post .navigation.pagination .next,
.single-post .navigation.pagination .prev,
.blog_widget ul li a,
.port-next.tt_button:hover,
.port-prev.tt_button:hover,
.port-next.tt_button:hover .fa,
.port-prev.tt_button:hover .fa,
.portfolio-block h4,
.rw-author-details h4,
.testimonials.slider .author,
.testimonials.slider .tt-content h6,
.navbar-default.navbar-shrink .modal-menu-item,
.vc_grid-item-mini .vc_gitem_row .vc_gitem-col h4,
.navbar-default.navbar-shrink .nav li a,
#main-menu .navbar-nav .dropdown-menu li a,
#main-menu .navbar-nav .menu-item-has-children:hover .dropdown-menu .dropdown:before,
.team-content h5,
.key-icon-box .service-heading,
#wp-calendar caption,
.post a:hover,
.search .page a:hover,
.search .product a:hover,
.search .portfolio a:hover,
.kd_pie_chart .kd_pc_title,
.kd_pie_chart .pc-link a,
.navigation.pagination .next:hover,
.navigation.pagination .prev:hover,
.testimonials .tt-content h4,
.kd-photobox .phb-content h4,
.kd-process-steps .pss-text-area h4,
.widget-title,
.kd-photobox.no-effect:hover .phb-content h4,
.kd-promobox .prb-content h4,
.kd_counter_units,
.large-counter .kd_counter_text,
.bp-content h4,
.pricing-table.light-scheme .pricing-title,
.kd-process-steps .pss-step-number span,
.reply-title,
.product_meta,
.testimonial-cards .tcards-title,
.group_table .label,
.testimonial-cards .tcards_header .tcards-name,
.woocommerce-result-count,
.pss-link a,
.woocommerce table.shop_attributes th,
.woocommerce .price_slider_wrapper .price_slider_amount,
.subscribe input[type="submit"],
.testimonials .tt-content .content {
		  color: #333;
	}

.blog-header .header-overlay,
.home.blog .navbar.navbar-default,
.single-portfolio .navbar.navbar-default,
.single-post .navbar.navbar-default,
.woocommerce-page .navbar.navbar-default,
.page-template-default .navbar.navbar-default,
.page-template-portfolio-php .navbar.navbar-default,
.attachment .navbar.navbar-default,
.pricing-table .tt_button,
.pricing-title,
.testimonials.slider .owl-controls span {
		  background-color: #333;
	}

.navigation.pagination .next:hover,
.navigation.pagination .prev:hover,
.port-next.tt_button:hover,
.port-prev.tt_button:hover,
.testimonials.slider .owl-controls .owl-page:hover span,
.testimonials.slider .owl-controls .owl-page.active span {
		  border-color: #333;
	}


.navbar-default.navbar-shrink .modal-menu-item {
		  border-color: #666;
	}

.socials-widget a .fa,
.key-icon-box a p {
	color: #666;
}

.wpcf7 .wpcf7-text::-webkit-input-placeholder {
	color: #333;
}
.wpcf7 .wpcf7-text::-moz-placeholder {
	color: #333;
}
.wpcf7 .wpcf7-text:-ms-input-placeholder {
	color: #333;
}


.upper-footer {
		  background-color: #636b75;
	}

.lower-footer {
		  background-color: #636b75;
	}

.lower-footer, .upper-footer {
		  color: #ffffff;
	}

.upper-footer .widget-title, .upper-footer .modal-menu-item {
		  color: #ffffff;
	}

.navbar.navbar-default.navbar-shrink.fixed-menu,
.keydesign-cart .keydesign-cart-dropdown,
.navbar.navbar-default .dropdown-menu,
.navbar.navbar-default {
	background-color: #000000 !important;
}











.single-portfolio #single-page, .portfolio-navigation-links {
	background-color: #fafafa;
}

body, .box {
	color: #666;
	font-weight: 400;
	font-family: "Lato";
	font-size: 16px;
	text-align: left;
	line-height: 30px;
}

.container h1,.container h2,.container h3, .pricing .col-lg-3, .chart, .pb_counter_number, .pc_percent_container {
	color: #333;
	font-weight: 700;
	font-family: Work Sans;
	font-size: 40px;
	text-align: center;
	line-height: 48px;
}

.navbar-default .nav li a, .modal-menu-item {
	font-weight: ;
		font-size: ;
	text-transform: ;
}

@media (max-width: 960px) {
	.navbar-default,
	.blog .navbar.navbar-default,
	.navbar-default.navbar-shrink, .home.page-template-default .navbar.navbar-default.navbar-shrink,
	.navbar.navbar-default .dropdown-menu {
						  background-color: #333;
				}
}
</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://allotelecom.ca/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.8 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />

<!-- BEGIN ExactMetrics v5.3.8 Universal Analytics - https://exactmetrics.com/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-69395029-1', 'auto');
  ga('send', 'pageview');
</script>
<!-- END ExactMetrics Universal Analytics -->
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
		<style type="text/css" id="wp-custom-css">
			h3.service-heading {
    font-size: 35px!important;
}
.page-id-2601 #wrapper {    padding-top: 107px;
}

#single-page.no-header-image .single-page-heading {
	background: url('http://allotelecom.ca/wp-content/uploads/2019/02/contact.jpg') no-repeat;
	background-size: cover;
	background-position: center;
    padding: 0;
    margin-bottom: 0;
    height: 250px;
}

#single-page.no-header-image .single-page-heading::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.45);
    z-index: 0;
}


#single-page h1.section-heading {
    color: #ffffff;
    margin-top: 30px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,100px);
    margin: 0 auto;
}


.box_title h4.service-heading {
    font-size: 23px!important;
    line-height: 33px!important;
}
.page-template-default #single-page { padding: 70px 0 0px!important }
.page-id-2601 #single-page { padding: 0!important}

#google_review_sec .rw_header { margin-bottom: 0px!important; }
#google_review_sec .key-reviews { padding: 10px 40px}

.blog .section {
    border-bottom: 4px solid #BF2928;
}
td.fa_check:before {
    font-family: FontAwesome;
    content: "\f00c";
    font-weight: 900;
    padding-left: 20px;
    font-size: 25px;
    color: #be2323;
}
td.fa_wifi:before {
    font-family: FontAwesome;
    content: "\f1eb";
    font-weight: 900;
    padding-left: 5px;
    font-size: 25px;
    color: #be2323;
}
.wpb_text_column ul li, .wpb_text_column ol li { margin-bottom: 0px!important; }
#single-page .ground_subscription img {
    width: 85%;
}
.border_faq {
    border: 2px solid #be2323;
    padding: 11px;
    margin-bottom: 30px;
    padding-bottom: 15px;
    color: #be2323;
}
.homepage_google_review {
    padding: 13px;
}
.homepage_google_review .rw_header {
    margin-bottom: -15px;
}
.homepage_google_review .rw_message { padding-top: 10px; line-height: 28px; padding-bottom: 15px; }
.homepage_google_review .rw_rating { padding-top: 15px; }
.page-template nav.navbar.navbar-default.navbar-fixed-top.fullwidth {
    background: #be2323;
}

i.fa.fa-thumbs-o-up.fa, i.fa.fa-users.fa, i.fa.fa-globe.fa, i.fa.fa-user-plus.fa{ color: #DD3333!important; }
.border_right {
    border-right: 2px solid;
}
.widget-title span {
    font-size: 22px;
    border-bottom: 1px solid;
    padding-bottom: 10px;
}
.footer_widget .menu li {
	display: block!important; }
.footer_widget .menu li a {
    font-size: 16px!important;
    font-weight: 600!important;
    line-height: 35px!important;
    text-transform: capitalize!important;
}
i.fa.fa-internet-explorer.fa {font-size: 70px;}
.business_form span.wpcf7-form-control-wrap {
    width: 100%!important;
}
.col-sm-3 span {
    width: 100%!important;
}
.fixed-logo { max-height: 60px!important; }
		</style>
	<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	  
   </head>
   <body class="error404 wpb-js-composer js-comp-ver-5.5.5 vc_responsive">        
              <div id="preloader">
           <div class="spinner"></div>
        </div>
      
      <!-- Contact Modal template -->
      <div class="modal fade popup-modal" id="popup-modal" role="dialog">
  <div class="modal-content">
      <div class="row">
                    <h2>Comment peut-on vous aider?</h2>
                    <div class="modal-content-inner">
                                <p class="modal-subheading">Pour toutes vos questions !</p>
                                                                         </div>
      </div>
      <button type="button" class="close" data-dismiss="modal">&times;</button>
  </div>
</div>
      <!-- END Contact Modal template -->

      <nav class="navbar navbar-default navbar-fixed-top fullwidth fixed-menu" >
		<div class="top-bar">
			<div class="container">
				<div class="type-list col-sm-4">
					<ul class="top_bar">
						<li><a href="http://allotelecom.ca">Residentiel</a></li> | <li><a href="http://allotelecom.ca/affaires">Affaires</a></li>
					</ul>
				</div> 
				<div class="type-list col-md-offset-3 col-sm-5 pull-right">
					<ul class="top_bar">
						<li><a href="tel:5147223236">(514) 722-3236</a></li> 
						<li><a href="tel:8555614405">Sans frais : (855) 561-4405</a></li>
						<li class="menu_lang">
<div class="wpml-ls-statics-footer wpml-ls wpml-ls-legacy-list-horizontal">
	<ul><li class="wpml-ls-slot-footer wpml-ls-item wpml-ls-item-en wpml-ls-first-item wpml-ls-last-item wpml-ls-item-legacy-list-horizontal">
				<a href="http://allotelecom.ca/en/" class="wpml-ls-link"><img class="wpml-ls-flag" src="http://allotelecom.ca/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.png" alt="en" title="English"></a>
			</li></ul>
</div></li>
					</ul>					
				</div> 
			</div>
		 </div>
         <div class="container">
            <div id="logo" class="col-sm-5">
               <a class="logo" href="http://allotelecom.ca">
                                <img class="fixed-logo" src="http://allotelecom.ca/wp-content/uploads/2019/02/white-lgoo.png" width=""  alt="Allo Telecom" />
                 <img class="nav-logo" src="http://allotelecom.ca/wp-content/uploads/2019/02/black_logo.png" width=""  alt="Allo Telecom" />
               </a>
            </div>
			<div class="navbar-header page-scroll col-sm-6">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                                        <div class="mobile-cart">
                                            </div>
                              </div>
            <div id="main-menu" class="collapse navbar-collapse  navbar-right col-sm-7">
               <ul id="menu-main-menu" class="nav navbar-nav"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-3220" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-3220"><a title="Accueil" href="http://allotelecom.ca/">Accueil</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-3227" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3227"><a title="Internet" href="/residential/forfaits-internet/">Internet</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-3229" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3229"><a title="Téléphone" href="/residential/telephone/">Téléphone</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-3228" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3228"><a title="Télévision" href="/residential/forfaits-tele/">Télévision</a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-3226" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3226"><a title="Forfaits" href="/residential/forfaits/">Forfaits</a></li>
</ul>                                       <a class="modal-menu-item menu-item" data-toggle="modal" data-target="#popup-modal">Contact</a>
                    <!-- WooCommerce Cart -->
                            <!-- END WooCommerce Cart -->
            </div>
         </div>
      </nav>


      <div id="wrapper" class="">
      <section class="page-404">
<div class="page404-overlay" style="background-image:url('http://allotelecom.ca/wp-content/themes/incubator/images/page-404.jpg')"></div>
<div class="container">
   <div class="row" >
      <h2 class="section-heading">Error 404</h2>
      <span class="separator"></span>
      <p class="section-subheading">This page could not be found!</p>
      <a href="http://allotelecom.ca" class="tt_button">Back to homepage</a>
   </div>
   </div>
</section>
</div>
<footer id="footer" class="classic">
      

    <div class="upper-footer">
        <div class="container">
            <div class="container">
                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 first-widget-area">
                        <div class="footer_widget"><h5 class="widget-title"><span>NOTRE SLOGAN</span></h5>			<div class="textwidget"><p><img src = "http://fiib.ca/wp-content/uploads/2019/02/white-lgoo.png" /></p>
<p>Nous sommes différents. Et heureux de l’être!</p>
<p>Nous croyons qu’il faut faire ce qui est juste. Pour nos clients. Pour notre entreprise. Pour notre équipe ALLO Telecom. Cela signifie que nous traitons les gens comme nous voudrions être traités. Équitablement. Honnêtement. Avec respect et considération. Cela signifie offrir un excellent service à un prix raisonnable.</p>
</div>
		</div>                    </div>
                
                
                                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 third-widget-area">
                    <div class="footer_widget"><h5 class="widget-title"><span>Contact</span></h5><div class="ciw_contactinformation"><div class="ciw_address" style="color: #fff">
											<i class="fa fa-map-marker"></i>	
												<div class="ciw_address_content">
													<div class="ciw_company_name">Allo Telecom</div>
													<div class="ciw_contact_address">6400 Bld Taschereau, Suite 225<br />
J4W 3J2, Brossard	</div>
												</div>
										</div><div class="ciw_phone">
												<i class="fa fa-phone"></i>
												<div class="ciw_contact_phone"><a href="tel:(514) 722-3236" style="color: #fff">(514) 722-3236</a></div>
											</div><div class="ciw_email">
												<i class="fa fa-envelope"></i>
												<div class="ciw_contact_email"><a href="mailto:sac@allotelecom.ca" target="_blank" style="color: #fff">sac@allotelecom.ca</a></div>
											</div></div></div>                </div>
                
                                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 forth-widget-area">
                    <div class="footer_widget"><h5 class="widget-title"><span>NOUS SUIVRE</span></h5><ul class="lsi-social-icons icon-set-lsi_widget-2" style="text-align: left"><li class="lsi-social-facebook"><a class="" rel="nofollow" title="Facebook" aria-label="Facebook" href="https://www.facebook.com/Allotelecommunication/" ><i class="lsicon lsicon-facebook"></i></a></li><li class="lsi-social-twitter"><a class="" rel="nofollow" title="Twitter" aria-label="Twitter" href="https://twitter.com/allo_telecom" ><i class="lsicon lsicon-twitter"></i></a></li><li class="lsi-social-instagram"><a class="" rel="nofollow" title="Instagram" aria-label="Instagram" href="https://www.instagram.com/allo_telecom/" ><i class="lsicon lsicon-instagram"></i></a></li><li class="lsi-social-youtube"><a class="" rel="nofollow" title="YouTube" aria-label="YouTube" href="https://www.youtube.com/channel/UCYt8z7X9a6XQ-kMW1z8VLbQ" ><i class="lsicon lsicon-youtube"></i></a></li></ul></div>                </div>
                                </div>
            </div>
        </div>
    </div>
      <div class="lower-footer">
          <div class="container">
             <div class="pull-left">
               <span>Allo Telecom. Tous droits réservés..</span>
            </div>
            <div class="pull-right">
               <ul id="menu-footer-menu" class="nav navbar-footer"><li id="menu-item-3023" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3023"><a href="http://allotelecom.ca/propos-allotelecom/">À Propos</a></li>
<li id="menu-item-3255" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-3255"><a href="http://allotelecom.ca/blog/">Blog</a></li>
<li id="menu-item-3256" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3256"><a href="http://allotelecom.ca/carrieres/">Carrières</a></li>
<li id="menu-item-3257" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3257"><a href="http://allotelecom.ca/faq/">FAQ</a></li>
<li id="menu-item-3022" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3022"><a href="http://allotelecom.ca/support/">Support</a></li>
<li id="menu-item-3258" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3258"><a href="http://allotelecom.ca/termes-et-conditions/">Termes &#038; Conditions</a></li>
<li id="menu-item-3259" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3259"><a href="http://allotelecom.ca/crtc">CRTC</a></li>
</ul>            </div>
         </div>
      </div>
</footer>

      <div class="back-to-top">
         <i class="fa fa-angle-up"></i>
      </div>

            <!-- Add Messenger - wp-chatbot - HoliThemes - https://www.holithemes.com/wp-chatbot -->    
            <div id="htcc-messenger" class="htcc-messenger">
                <div id="htcc-customerchat" class="fb-customerchat"
                page_id="432693146882678"
                theme_color=""
                logged_in_greeting="Vous avez une questions?"
                logged_out_greeting=""
                ref="dfd32cb426bc534ea9daaaaa2e23e48161028c7895dda2b3aca61688e14126c35b44be8ed3b2caeba4a647defbdda8cd6eec"
                greeting_dialog_display = ""
                greeting_dialog_delay = ""
                >
                </div>
            </div>
            <!-- / Add Messenger - wp-chatbot - HoliThemes -->   

            <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="pswp__bg"></div>
        <div class="pswp__scroll-wrap">
            <div class="pswp__container">
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
            </div>
            <div class="pswp__ui pswp__ui--hidden">
                <div class="pswp__top-bar">
                    <div class="pswp__counter"></div>
                    <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
                    <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
                    <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
                    <div class="pswp__preloader">
                        <div class="pswp__preloader__icn">
                          <div class="pswp__preloader__cut">
                            <div class="pswp__preloader__donut"></div>
                          </div>
                        </div>
                    </div>
                </div>
                <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
                </button>
                <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
                </button>
                <div class="pswp__caption">
                    <div class="pswp__caption__center"></div>
                </div>
            </div>
        </div>
    </div><noscript><img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=1741670889437646&ev=PageView&noscript=1" alt="facebook_pixel"></noscript>
<noscript><img height="1" width="1" style="display: none;" src="https://www.facebook.com/tr?id=1741670889437646&ev=GeneralEvent&noscript=1" alt="facebook_pixel"></noscript>
<link rel='stylesheet' id='lsi-style-css'  href='http://allotelecom.ca/wp-content/plugins/lightweight-social-icons/css/style-min.css?ver=1.0.1' type='text/css' media='all' />
<style id='lsi-style-inline-css' type='text/css'>
.icon-set-lsi_widget-2 a,
			.icon-set-lsi_widget-2 a:visited,
			.icon-set-lsi_widget-2 a:focus {
				border-radius: 5px;
				background: #1E72BD !important;
				color: #FFFFFF !important;
				font-size: 20px !important;
			}

			.icon-set-lsi_widget-2 a:hover {
				background: #dd3333 !important;
				color: #FFFFFF !important;
			}
</style>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/allotelecom.ca\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/themes/incubator/core/assets/js/bootstrap.min.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/themes/incubator/core/assets/js/SmoothScroll.js?ver=5.0.3'></script>
<script type='text/javascript' src='http://allotelecom.ca/wp-content/themes/incubator/core/assets/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript'>
                                            
</script>
<script type='text/javascript' src='http://allotelecom.ca/wp-includes/js/wp-embed.min.js?ver=5.0.3'></script>
</body>
</html>
